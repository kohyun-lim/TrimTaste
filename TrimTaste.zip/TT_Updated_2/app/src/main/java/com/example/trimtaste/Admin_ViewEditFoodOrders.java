package com.example.trimtaste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Admin_ViewEditFoodOrders extends AppCompatActivity {

    public DatabaseHelper databaseHelper;
    public EditText edTxtUserId, edTxtOrderId;
    public Button btnGenReport, btnReady;
    public TextView txtViewReport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_view_edit_food_orders);

        btnGenReport = findViewById(R.id.btnGenerateReport);
        btnReady = findViewById(R.id.btnReady);

        edTxtUserId = findViewById(R.id.txtUserId);
        edTxtOrderId = findViewById(R.id.txtOrderNum);
        txtViewReport = findViewById(R.id.txtViewReport);

        databaseHelper = new DatabaseHelper(this);


        btnGenReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userId = edTxtUserId.getText().toString();
                String orderNum = edTxtOrderId.getText().toString();

                List<String> orderInfo = databaseHelper.getOrdersByNumberWithUser(userId, orderNum);
                String totalAmount = String.valueOf(databaseHelper.getTotalAmountForOrder(orderNum));
                String result = "";

                for (String orderItem : orderInfo) {
                    result += orderItem.replace(",", ",\n") + "\n";
                }

                txtViewReport.setText(result+"Total amount: $"+totalAmount);

            }
        });

        btnReady.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userId = edTxtUserId.getText().toString();
                String orderNum = edTxtOrderId.getText().toString();

                // Update the status of the order to "Ready"
                databaseHelper.updateStatus(userId, orderNum, "Ready");
                Toast.makeText(Admin_ViewEditFoodOrders.this,"Order Ready",Toast.LENGTH_LONG).show();
            }
        });

    }
}
