package com.example.trimtaste;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class Admin_Report extends AppCompatActivity {

    public DatabaseHelper databaseHelper;
    public EditText edTxtUserId, edTxtOrderId;
    public Button btnGenReport;
    public TextView txtViewReport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_report);

        btnGenReport = findViewById(R.id.btnGenerateReport);

        edTxtUserId = findViewById(R.id.txtUserId);
        edTxtOrderId = findViewById(R.id.txtOrderNum);
        txtViewReport = findViewById(R.id.txtViewReport);

        databaseHelper = new DatabaseHelper(this);

        btnGenReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userId = edTxtUserId.getText().toString();
                String orderNum = edTxtOrderId.getText().toString();

                List<String> orderInfo = databaseHelper.getOrdersByNumberWithUser(userId, orderNum);

                String result = "";

                for (String orderItem : orderInfo) {
                    result += orderItem.replace(",", ",\n") + "\n";
                }

                txtViewReport.setText(result);
            }
        });

    }
}