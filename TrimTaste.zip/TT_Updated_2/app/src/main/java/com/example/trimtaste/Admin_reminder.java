package com.example.trimtaste;

import static com.example.trimtaste.DatabaseHelper.T4COL_1;
import static com.example.trimtaste.DatabaseHelper.T4COL_3;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.util.List;

public class Admin_reminder extends Activity {
    private static final String CHANNEL_ID = "reminder_channel";
    private static final int NOTIFICATION_ID = 123;
    private Button btnReminder;
    private DatabaseHelper databaseHelper;
    private EditText edTxtOrderNum;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_reminder);
        btnReminder = findViewById(R.id.btnReminder);
        edTxtOrderNum = findViewById(R.id.txtOrderNum);

        databaseHelper = new DatabaseHelper(this);

        btnReminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String orderNum = edTxtOrderNum.getText().toString();

                String status = getOrderStatus(orderNum);
                Toast.makeText(Admin_reminder.this, status, Toast.LENGTH_SHORT).show();

                if (status != null && status.equalsIgnoreCase("Ready")) {
                    sendNotification();
                    Toast.makeText(Admin_reminder.this, "Notification sent", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Admin_reminder.this, "Order is not ready yet", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }

    private String getOrderStatus(String orderId) {
        return databaseHelper.getOrderStatus(orderId);
    }


    private void sendNotification() {
        createNotificationChannel();

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.trimtaste_logo)
                .setContentTitle(getString(R.string.notification_title))
                .setContentText(getString(R.string.notification_message))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}