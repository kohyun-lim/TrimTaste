package com.example.trimtaste;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class User_Order extends AppCompatActivity {
    DatabaseHelper db ;
    double totalCost = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_order);
        TextView txtViewStatus = findViewById(R.id.txtViewStatus);

        // Instantiate the DatabaseHelper class
        db = new DatabaseHelper(this);

        List<String> orderNumbers = db.getOrderNumbers();

        // Create an ArrayAdapter for the order numbers
        ArrayAdapter<String> orderNumberAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, orderNumbers);

        // Get the ListView for the order numbers
        ListView orderNumberListView = findViewById(R.id.order_number_list_view);
        orderNumberListView.setAdapter(orderNumberAdapter);

        // Set an item click listener for the order number ListView
        orderNumberListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String orderNumber = (String) parent.getItemAtPosition(position);

                // Get the orders for the selected order number
                List<String> orderList = db.getOrdersByNumber(orderNumber);

                // Create an ArrayAdapter for the orders
                ArrayAdapter<String> orderListAdapter = new ArrayAdapter<>(User_Order.this, android.R.layout.simple_list_item_1, orderList);

                // Get the ListView for the orders
                ListView orderListView = findViewById(R.id.order_list_view);
                orderListView.setAdapter(orderListAdapter);


                SharedPreferences sh = getSharedPreferences("FoodSharedPref",MODE_PRIVATE);
                String orderNum = sh.getString("orderNum", "");
                String[] menuItems = db.getItemsFromOrder(orderNum);

                //get total display total
                TextView txtViewTotalCost = findViewById(R.id.txtViewTotalCost);
                for (String menuItem : menuItems) {
                    double menuItemPrice = db.getMenuItemPrice(menuItem);
                    totalCost += menuItemPrice;
                }
                String totalCostString = Double.toString(totalCost);
                txtViewTotalCost.setText("$" + totalCostString);

                txtViewStatus.setText("Ordered");
            }
        });




    }


}