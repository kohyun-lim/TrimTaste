package com.example.trimtaste;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class Restaurant8 extends AppCompatActivity
        implements User_RestaurantAdapter.ItemClickListener{

    Integer[] foodItems ={R.drawable.seafood_pizza,R.drawable.seafood_pizza,R.drawable.seafood_pizza,
            R.drawable.seafood_pizza,R.drawable.seafood_pizza};
    ImageView imageView;

    User_RestaurantAdapter adapter;

    Button btnAdd, btnDelete, btnConfirm;

    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant8);
        imageView = findViewById(R.id.imgLarge);
        btnAdd = findViewById(R.id.btnAddToOrder);
        btnDelete = findViewById(R.id.btnDeleteFromOrder);
        btnConfirm = findViewById(R.id.btnConfirm);

        // Instantiate the DatabaseHelper class
        DatabaseHelper db = new DatabaseHelper(this);

        String[] menuItems = db.getMenuItems(1);
        int menuItemsLen = menuItems.length;

        if(menuItemsLen == 1){
            Integer[] foodItems ={R.drawable.seafood_pizza};

            RecyclerView recyclerView = findViewById(R.id.recyclerView9);
            int numOfColumns = 1;
            recyclerView.setLayoutManager(new GridLayoutManager
                    (this,numOfColumns));
            //recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new User_RestaurantAdapter(this,foodItems,menuItems);
            adapter.setClickListener(this);
            recyclerView.setAdapter(adapter);
        } else if(menuItemsLen == 2){
            Integer[] foodItems ={R.drawable.seafood_pizza, R.drawable.seafood_pizza};

            RecyclerView recyclerView = findViewById(R.id.recyclerView9);
            int numOfColumns = 1;
            recyclerView.setLayoutManager(new GridLayoutManager
                    (this,numOfColumns));
            //recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new User_RestaurantAdapter(this,foodItems,menuItems);
            adapter.setClickListener(this);
            recyclerView.setAdapter(adapter);
        } else if(menuItemsLen == 3){
            Integer[] foodItems ={R.drawable.seafood_pizza, R.drawable.seafood_pizza, R.drawable.seafood_pizza};

            RecyclerView recyclerView = findViewById(R.id.recyclerView9);
            int numOfColumns = 1;
            recyclerView.setLayoutManager(new GridLayoutManager
                    (this,numOfColumns));
            //recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new User_RestaurantAdapter(this,foodItems,menuItems);
            adapter.setClickListener(this);
            recyclerView.setAdapter(adapter);
        } else if(menuItemsLen == 4){
            Integer[] foodItems ={R.drawable.seafood_pizza, R.drawable.seafood_pizza, R.drawable.seafood_pizza,
                    R.drawable.seafood_pizza};

            RecyclerView recyclerView = findViewById(R.id.recyclerView9);
            int numOfColumns = 1;
            recyclerView.setLayoutManager(new GridLayoutManager
                    (this,numOfColumns));
            //recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new User_RestaurantAdapter(this,foodItems,menuItems);
            adapter.setClickListener(this);
            recyclerView.setAdapter(adapter);
        } else if(menuItemsLen == 5){
            Integer[] foodItems ={R.drawable.seafood_pizza, R.drawable.seafood_pizza, R.drawable.seafood_pizza,
                    R.drawable.seafood_pizza, R.drawable.seafood_pizza};

            RecyclerView recyclerView = findViewById(R.id.recyclerView9);
            int numOfColumns = 1;
            recyclerView.setLayoutManager(new GridLayoutManager
                    (this,numOfColumns));
            //recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new User_RestaurantAdapter(this,foodItems,menuItems);
            adapter.setClickListener(this);
            recyclerView.setAdapter(adapter);
        } else if(menuItemsLen == 6){
            Integer[] foodItems ={R.drawable.seafood_pizza, R.drawable.seafood_pizza, R.drawable.seafood_pizza,
                    R.drawable.seafood_pizza, R.drawable.seafood_pizza, R.drawable.seafood_pizza};

            RecyclerView recyclerView = findViewById(R.id.recyclerView9);
            int numOfColumns = 1;
            recyclerView.setLayoutManager(new GridLayoutManager
                    (this,numOfColumns));
            //recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new User_RestaurantAdapter(this,foodItems,menuItems);
            adapter.setClickListener(this);
            recyclerView.setAdapter(adapter);
        } else if(menuItemsLen == 7){
            Integer[] foodItems ={R.drawable.seafood_pizza, R.drawable.seafood_pizza, R.drawable.seafood_pizza,
                    R.drawable.seafood_pizza, R.drawable.seafood_pizza, R.drawable.seafood_pizza, R.drawable.seafood_pizza};

            RecyclerView recyclerView = findViewById(R.id.recyclerView9);
            int numOfColumns = 1;
            recyclerView.setLayoutManager(new GridLayoutManager
                    (this,numOfColumns));
            //recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new User_RestaurantAdapter(this,foodItems,menuItems);
            adapter.setClickListener(this);
            recyclerView.setAdapter(adapter);
        } else if(menuItemsLen == 8){
            Integer[] foodItems ={R.drawable.seafood_pizza, R.drawable.seafood_pizza, R.drawable.seafood_pizza,
                    R.drawable.seafood_pizza, R.drawable.seafood_pizza, R.drawable.seafood_pizza, R.drawable.seafood_pizza,
                    R.drawable.seafood_pizza};

            RecyclerView recyclerView = findViewById(R.id.recyclerView9);
            int numOfColumns = 1;
            recyclerView.setLayoutManager(new GridLayoutManager
                    (this,numOfColumns));
            //recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new User_RestaurantAdapter(this,foodItems,menuItems);
            adapter.setClickListener(this);
            recyclerView.setAdapter(adapter);
        }

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Restaurant8.this, User_ConfirmOrder.class));
            }
        });

    }

    @Override
    public void onItemClick(View view, int position) {
        DatabaseHelper db = new DatabaseHelper(this);

        String[] menuItems2 = db.getMenuItems(8);

        int menuId = db.getMenuItemId(menuItems2[position]);

        boolean menuItemFound = db.displayMenuInfo(menuId);

        SharedPreferences userSh = getSharedPreferences("MySharedPref",MODE_PRIVATE);

        SharedPreferences sh = getSharedPreferences("FoodSharedPref",MODE_PRIVATE);
        SharedPreferences.Editor foodEdit = sh.edit();

        if(menuItemFound){
            String menuItemName = db.getMenuItemName();
            String menuItemPrice = db.getMenuItemPrice();
            String menuItemResId = db.getMenuRestaurantId();

            foodEdit.putString("orderNum", menuItemResId);
            foodEdit.commit();

            String user = userSh.getString("username", "");
            db.displayUserProfile(user);
            String userId = db.getUserId();

            Log.d("MenuItemInfo", "Menu Item Name " + menuItemName);
            Log.d("MenuItemInfo", "Menu Item Price " + menuItemPrice);
            Log.d("MenuItemInfo", "Menu Item ResID " + menuItemResId);
            Log.d("MenuItemInfo", "UserID " + userId);

            btnAdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String menuIdd = Integer.toString(menuId);
                    String status = "Ordered";
                    db.addOrder(userId, menuItemResId, menuItemResId, menuIdd,
                            menuItemName, " ", menuItemPrice, status);


                }
            });

        }

        Toast.makeText(this,"Selected specie" + (position+1),
                Toast.LENGTH_SHORT).show();
        imageView.setImageResource(adapter.getItem(position));

    }
}